package com.example.mahasiswapc.room.entity;

import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;
import android.arch.persistence.room.Update;
import java.util.List;

public interface DataMakananDAO {
    @Insert
    Long insertData(DataMakanan dataMakanan);

    @Query("Select * from tbl_makanan")
    List<DataMakanan> getData();

    @Update
    int updateData (DataMakanan item);

    @Delete
    int deleteData (DataMakanan item);
}
