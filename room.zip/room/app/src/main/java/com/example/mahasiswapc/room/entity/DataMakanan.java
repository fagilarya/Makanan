package com.example.mahasiswapc.room.entity;

import android.arch.persistence.room.ColumnInfo;
import android.arch.persistence.room.Entity;
import android.arch.persistence.room.PrimaryKey;
import android.support.annotation.NonNull;

@Entity (tableName = "tbl_makanan")
public class DataMakanan {
    @NonNull
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id" )
    private int id;

    @ColumnInfo(name = "nama" )
    private String nama;

    @ColumnInfo(name = "kategori" )
    private String kategori;

    @ColumnInfo(name = "harga" )
    private String harga;

    @ColumnInfo(name = "jumlah" )
    private String jumlah;

    @NonNull
    public int getId()
    {     return id;    }

    public void setId(@NonNull int id)
    {     this.id = id;    }

    public String getNama()
    {     return nama;    }

    public void setNama(String nama)
    {     this.nama = nama;    }

    public String getKategori()
    {     return kategori;    }

    public void setKategori(String kategori)
    {     this.kategori = kategori;    }

    public String getHarga()
    {     return harga;    }

    public void setHarga(String harga)
    {     this.harga = harga;    }

    public String getJumlah()
    {     return jumlah;    }

    public void setJumlah(String jumlah)
    {     this.jumlah = harga;    }
}
