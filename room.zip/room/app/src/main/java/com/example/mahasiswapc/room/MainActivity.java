package com.example.mahasiswapc.room;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.mahasiswapc.room.entity.AppDB;
import com.example.mahasiswapc.room.entity.DataMakanan;

public class MainActivity extends AppCompatActivity{
    private AppDB appDB;

    private Button btnSub, btnData;
    private EditText tvNama, tvKategori, tvHarga, tvJumlah;
    private String nama, kategori, harga, jumlah;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        appDB = AppDB.iniDb(getApplicationContext());

        btnSub = findViewById(R.id.btn_submit);
        btnSub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                input();
            }
        });
        btnData = findViewById(R.id.btn_data);
        // btnData.setOnClickListener(this);
        tvNama = findViewById(R.id.et_nama);
        tvKategori = findViewById(R.id.et_kategori);
        tvHarga = findViewById(R.id.et_harga);
        tvJumlah = findViewById(R.id.et_jumlah);
    }

    void input(){
        nama = tvNama.getText().toString();
        kategori = tvKategori.getText().toString();
        harga = tvHarga.getText().toString();
        jumlah = tvJumlah.getText().toString();

        final DataMakanan dataMakanan = new DataMakanan();
        dataMakanan.setNama(nama);
        dataMakanan.setKategori(kategori);
        dataMakanan.setHarga(harga);
        dataMakanan.setJumlah(jumlah);
    }

    class InsertData extends AsyncTask<Void, Void, Long> {
        private AppDB database;
        private DataMakanan dataMakanan;

        public InsertData(AppDB database, DataMakanan dataMakanan) {
            this.database = database;
            this.dataMakanan = dataMakanan;
        }

        @Override
        protected Long doInBackground(Void... voids) {
            return database.dao().insertData(dataMakanan);
        }

    }
}
