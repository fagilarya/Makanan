package com.example.mahasiswapc.room.entity;

import android.arch.persistence.room.Database;
import android.arch.persistence.room.Room;
import android.arch.persistence.room.RoomDatabase;
import android.content.Context;

@Database(entities = {DataMakanan.class} , version = 1)
public abstract class AppDB extends RoomDatabase {
    public abstract DataMakananDAO dao();
    private static AppDB appDB;

    public static AppDB iniDb(Context context){
        if(appDB == null)
            appDB = Room.databaseBuilder(context, AppDB.class,
                    "db_makanan").allowMainThreadQueries().build();

        return appDB;
    }

    public static void destroyInstance() {
        appDB = null;
    }
}
